<?php

declare(strict_types=1);

namespace MongoDB\Builder\Type;

/** @see https://www.mongodb.com/docs/manual/reference/operator/query/geometry/ */
interface GeometryInterface
{
}

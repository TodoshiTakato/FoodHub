<?php

declare(strict_types=1);

namespace MongoDB\Laravel\Query;

use Illuminate\Database\Query\Grammars\Grammar as BaseGrammar;

class Grammar extends BaseGrammar
{
}
